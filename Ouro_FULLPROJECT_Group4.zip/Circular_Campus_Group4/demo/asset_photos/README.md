# Demo asset photos

AI-generated pictures for the demo. They are illustrations, not photos of KU's real items.

Name each file after the asset, lowercase, with dashes instead of spaces and punctuation
(`.jpg`, `.png` or `.webp`, landscape, about 1200 × 675):

| Asset                     | File name                          |
|---------------------------|------------------------------------|
| Stackable lab stool       | stackable-lab-stool.jpg            |
| Ergonomic office chair    | ergonomic-office-chair.jpg         |
| Laptop docking station    | laptop-docking-station.jpg         |
| Dell 24-inch monitor      | dell-24-inch-monitor.jpg           |
| LG 22-inch monitor        | lg-22-inch-monitor.jpg             |
| Bookshelf, five shelves   | bookshelf-five-shelves.jpg         |
| Bench power supply, 30 V  | bench-power-supply-30-v.jpg        |
| Mobile whiteboard         | mobile-whiteboard.jpg              |

Then run:

    python manage.py demo_photos            # adds photos to assets that have none
    python manage.py demo_photos --replace  # swaps in new versions of these photos

`seed_demo` also runs this step, so a fresh database gets the photos automatically.
Assets without a file keep their category icon.
