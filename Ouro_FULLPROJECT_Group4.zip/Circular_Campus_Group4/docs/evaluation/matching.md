# Matching relevance (lexical embedder, circular-campus-lexical-1)

| Queries | Hit@1 | Hit@3 | MRR | No result |
|---|---|---|---|---|
| All (25) | 100% | 100% | 1.00 | 0% |
| English (13) | 100% | 100% | 1.00 | 0% |
| Arabic (12) | 100% | 100% | 1.00 | 0% |

| Query | Expected | First relevant at | Top result (score) |
|---|---|---|---|
| display screen for a lab PC | Monitors | 1 | Samsung 27-inch monitor (91) |
| two monitors for a workstation | Monitors | 1 | Samsung 27-inch monitor (91) |
| seats for a seminar | Chairs, Stools | 1 | Ergonomic office chair (89) |
| office chair with armrests | Chairs | 1 | Ergonomic office chair (89) |
| something to show slides in a lecture | Projectors | 1 | Classroom projector (87) |
| beamer for a classroom | Projectors | 1 | Classroom projector (87) |
| USB-C dock for laptops | Docking stations | 1 | Laptop docking station (87) |
| storage for books | Shelving | 1 | Bookshelf, five shelves (84) |
| bookcase | Shelving | 1 | Bookshelf, five shelves (84) |
| scope to look at signals | Oscilloscopes | 1 | Digital oscilloscope, 100 MHz (87) |
| bench power supply for an electronics lab | Power supplies | 1 | Bench power supply, 30 V (84) |
| 3D printer for prototyping | 3D printers | 1 | Desktop 3D printer (98) |
| board to write on for a meeting room | Whiteboards | 1 | Mobile whiteboard (88) |
| شاشة عرض | Monitors | 1 | Samsung 27-inch monitor (91) |
| شاشتان لمختبر | Monitors | 1 | Samsung 27-inch monitor (91) |
| كراسي لقاعة الندوات | Chairs, Stools | 1 | Ergonomic office chair (89) |
| كرسي مكتب | Chairs | 1 | Ergonomic office chair (89) |
| بروجكتر للمحاضرات | Projectors | 1 | Classroom projector (87) |
| عارض شرائح | Projectors | 1 | Classroom projector (87) |
| رفوف للكتب | Shelving | 1 | Bookshelf, five shelves (84) |
| طابعة ثلاثية الأبعاد | 3D printers | 1 | Desktop 3D printer (92) |
| مزود طاقة للمختبر | Power supplies | 1 | Bench power supply, 30 V (84) |
| سبورة متحركة | Whiteboards | 1 | Mobile whiteboard (88) |
| راسم الإشارة | Oscilloscopes | 1 | Digital oscilloscope, 100 MHz (87) |
| منصة توصيل للابتوب | Docking stations | 1 | Laptop docking station (87) |
