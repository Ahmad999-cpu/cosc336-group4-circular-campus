"""Django settings for Circular Campus. Values come from environment variables (see .env.example)."""
import os
from pathlib import Path

from django.utils.translation import gettext_lazy as _

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_env_file(path: Path) -> None:
    """Minimal .env loader so the project has no extra dependency for it."""
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip())


_load_env_file(BASE_DIR / ".env")


def env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


SECRET_KEY = env("DJANGO_SECRET_KEY", "dev-only-insecure-key-change-me")
DEBUG = env("DJANGO_DEBUG", "1") == "1"
INTERNAL_IPS = ["127.0.0.1"]
ALLOWED_HOSTS = [h for h in env("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1").split(",") if h]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # Business modules, lowest layer first (component diagram, Figure 7.12)
    "apps.access",
    "apps.audit",
    "apps.notifications",
    "apps.ai",
    "apps.catalogue",
    "apps.blueprint",
    "apps.resource_requests",
    "apps.transfers",
    "apps.lifecycle",
    "apps.sustainability",
    "apps.matching",
    "apps.reporting",
    "apps.web",
    "apps.guest",  # public pages for visitors (home, how it works, contact)
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.locale.LocaleMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "apps.access.middleware.SessionActivityMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "apps.web.middleware.DomainErrorMiddleware",
    "apps.web.middleware.HtmxEdgeMiddleware",
]
CSRF_FAILURE_VIEW = "apps.web.views.csrf_failure"

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "apps.web.context.navigation",
                "apps.guest.context.brand",
                "django.template.context_processors.debug",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": env("POSTGRES_DB", "circular_campus"),
        "USER": env("POSTGRES_USER", "postgres"),
        "PASSWORD": env("POSTGRES_PASSWORD", "postgres"),
        "HOST": env("POSTGRES_HOST", "localhost"),
        "PORT": env("POSTGRES_PORT", "5432"),
        "ATOMIC_REQUESTS": False,  # services open their own transactions where they need them
    }
}

AUTH_USER_MODEL = "access.User"
LOGIN_URL = "access:login"
LOGIN_REDIRECT_URL = "web:home"
LOGOUT_REDIRECT_URL = "access:login"

# NFR-16: Argon2id first; the others only verify old hashes.
PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.Argon2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2PasswordHasher",
]

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# NFR-17: 15 minutes of inactivity ends the session.
SESSION_COOKIE_AGE = 15 * 60
SESSION_SAVE_EVERY_REQUEST = False  # SessionActivityMiddleware renews it on real activity only
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_HTTPONLY = False
SESSION_COOKIE_SECURE = not DEBUG
CSRF_COOKIE_SECURE = not DEBUG
if not DEBUG:  # production (the pilot): HTTPS only, and never the development secret key
    from django.core.exceptions import ImproperlyConfigured
    if SECRET_KEY.startswith("dev-only"):
        raise ImproperlyConfigured("Set DJANGO_SECRET_KEY to a long random value before running with DJANGO_DEBUG=0")
    SECURE_SSL_REDIRECT = env("DJANGO_SSL_REDIRECT", "1") == "1"
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    SECURE_HSTS_SECONDS = int(env("DJANGO_HSTS_SECONDS", "3600"))

# Arabic and English (bonus feature). Mark every user-facing string with gettext / {% translate %}.
LANGUAGE_CODE = "en"
LANGUAGES = [("en", _("English")), ("ar", _("العربية"))]
LOCALE_PATHS = [BASE_DIR / "locale"]
FORMAT_MODULE_PATH = ["config.formats"]
TIME_ZONE = "Asia/Dubai"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"
MEDIA_URL = "media/"
MEDIA_ROOT = BASE_DIR / "media"
FILE_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# E-mail: printed to the console in development; the worker delivers the outbox (ADR-4).
EMAIL_BACKEND = env("EMAIL_BACKEND", "django.core.mail.backends.console.EmailBackend")
EMAIL_HOST = env("EMAIL_HOST", "")
EMAIL_PORT = int(env("EMAIL_PORT", "587"))
EMAIL_HOST_USER = env("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD", "")  # server-side only, never sent to the browser
EMAIL_USE_TLS = env("EMAIL_USE_TLS", "1") == "1"
EMAIL_TIMEOUT = 15
DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL", "circular-campus@localhost")

# AI (ADR-3, ADR-5). "fake" works offline and in tests.
# Feature 1: public address of this server, used in QR labels (e.g. https://circular.example.edu). Empty = take it
# from the incoming request, which is fine on a laptop but wrong for labels you print.
SITE_BASE_URL = env("SITE_BASE_URL", "").rstrip("/")

# Guest site. BRAND_NAME is the product name the guest pages show (one place to change for a rename).
BRAND_NAME = env("BRAND_NAME", "Circular Campus")
GUEST_CTA_URL = env("GUEST_CTA_URL", "")            # "Create your account" / "Get started"; empty = the sign-in page
GUEST_HOME_VIDEO = env("GUEST_HOME_VIDEO", "video/circular-campus-film.mp4")  # under static/, or a full https:// URL; empty = placeholder
GUEST_HOME_VIDEO_POSTER = env("GUEST_HOME_VIDEO_POSTER", "video/circular-campus-poster.jpg")
CONTACT_PHONE = env("CONTACT_PHONE", "0505733540")
CONTACT_EMAIL = env("CONTACT_EMAIL", "circularcampus.team@gmail.com")      # shown on the page
CONTACT_RECIPIENT = env("CONTACT_RECIPIENT", "circularcampus.team@gmail.com")  # where form messages go
CONTACT_RATE_LIMIT = int(env("CONTACT_RATE_LIMIT", "5"))  # messages per hour per visitor address

AI_PROVIDER = env("AI_PROVIDER", "fake")
ANTHROPIC_API_KEY = env("ANTHROPIC_API_KEY")
# Used when AI_PROVIDER=anthropic and the active ModelVersion was not made for Anthropic.
ANTHROPIC_MODEL = env("ANTHROPIC_MODEL", "claude-haiku-5-5")
EMBEDDING_MODEL = env("EMBEDDING_MODEL", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
# "lexical" works offline with no download; "sentence-transformers" uses the model above (requirements-ai.txt).
EMBEDDING_BACKEND = env("EMBEDDING_BACKEND", "lexical")

LOGGING = {
    "version": 1,
    "handlers": {"console": {"class": "logging.StreamHandler"}},
    "root": {"handlers": ["console"], "level": "INFO"},
}
