# UAE usage: Western digits with comma thousands and a dot for decimals (Django's default Arabic locale uses
# "." for thousands and "," for decimals, which reads as 1.260 / 0,5 on screens shared with English users).
DECIMAL_SEPARATOR = "."
THOUSAND_SEPARATOR = ","
NUMBER_GROUPING = 3
DATE_FORMAT = "j F Y"
SHORT_DATE_FORMAT = "d/m/Y"
