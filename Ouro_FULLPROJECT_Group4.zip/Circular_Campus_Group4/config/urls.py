from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),  # developer admin (seeding, debugging) - not the user interface
    path("i18n/", include("django.conf.urls.i18n")),  # language switch (POST /i18n/setlang/)
    path("accounts/", include("apps.access.urls")),
    path("assets/", include("apps.catalogue.urls")),
    path("requests/", include("apps.resource_requests.urls")),
    path("approvals/", include("apps.transfers.urls")),
    path("lifecycle/", include("apps.lifecycle.urls")),
    path("find/", include("apps.matching.urls")),
    path("impact/", include("apps.sustainability.urls")),
    path("reports/", include("apps.reporting.urls")),
    path("notifications/", include("apps.notifications.urls")),
    path("audit/", include("apps.audit.urls")),
    path("ai/", include("apps.ai.urls")),
    path("setup/", include("apps.blueprint.urls")),
    path("", include("apps.guest.urls")),  # public pages: /how-it-works/, /contact/
    path("", include("apps.web.urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
