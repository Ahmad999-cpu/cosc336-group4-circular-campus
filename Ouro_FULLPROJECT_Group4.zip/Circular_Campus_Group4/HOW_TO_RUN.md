# Circular Campus — how to run (COSC 336, Group 4)

The complete project is in this folder. Pick ONE of the two options.

## Option A — Docker (easiest, one command)

Needs Docker Desktop.

```bash
docker compose up --build
```

Wait for "Circular Campus is running", then open **http://localhost:8000**.
This creates the database, sets up the tables and loads the demo data for you.

## Option B — Without Docker

Needs Python 3.12+ and PostgreSQL 16 with the pgvector extension.

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                 # edit the POSTGRES_* lines if your database settings differ
python manage.py migrate
python manage.py seed_demo
python manage.py runserver           # open http://localhost:8000
```

## Signing in

All demo accounts use the password **demo-pass-2026**, or use the one-click buttons on the sign-in page.

| Role | E-mail |
|---|---|
| Requester | requester@demo.local |
| Club president | club@demo.local |
| Custodian | custodian@demo.local |
| Approver | approver@demo.local |
| Facilities | facilities@demo.local |
| Sustainability officer | sustain@demo.local |
| System administrator | admin@demo.local |

The public calculator works without signing in: http://localhost:8000/impact/calculator/

## Tests (optional)

```bash
pip install -r requirements-test.txt
python manage.py test                # 345 tests
```

No API keys are needed: the AI features run in offline demo mode by default. See README.md for full details.
