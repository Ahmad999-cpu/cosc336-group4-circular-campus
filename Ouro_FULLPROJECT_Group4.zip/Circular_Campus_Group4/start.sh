#!/bin/sh
# Starts the whole app inside Docker: waits for the database, sets it up, loads the demo data, then runs.
set -e
until python -c "import psycopg,os; psycopg.connect(host=os.environ['POSTGRES_HOST'],user='postgres',password='postgres',dbname='circular_campus').close()" 2>/dev/null; do
  echo "Waiting for the database..."; sleep 2
done
python manage.py migrate --noinput
python manage.py seed_demo
python manage.py runworker &
echo "Circular Campus is running: open http://localhost:8000"
exec python manage.py runserver 0.0.0.0:8000
