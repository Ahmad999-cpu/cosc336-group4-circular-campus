"""Bonus: Arabic / English interface. Arabic pages are right-to-left, translated, and so are messages people receive."""
import uuid

from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import translation

from apps.common.errors import ValidationFailed
from apps.notifications.models import Channel, Notification
from apps.notifications.services import Msg
from apps.resource_requests import services as req_services
from apps.web.templatetags.ui import aed, tr

from .factories import World


class ArabicInterfaceTests(TestCase):
    def setUp(self):
        self.w = World(qty=3)
        self.client.force_login(self.w.requester)

    def switch(self, lang):
        self.client.post(reverse("set_language"), {"language": lang, "next": "/"})

    def test_switching_sets_rtl_and_translates_screens(self):
        self.switch("ar")
        r = self.client.get(reverse("resource_requests:mine"))
        self.assertContains(r, 'lang="ar" dir="rtl"')
        self.assertContains(r, "طلباتي")
        self.assertContains(r, "English")  # the switch back
        for name, text in [("matching:find", "ماذا تحتاج؟"), ("sustainability:dashboard", "الأثر"),
                           ("notifications:index", "الإشعارات"), ("catalogue:browse", "تصفّح")]:
            self.assertContains(self.client.get(reverse(name)), text)
        self.switch("en")
        self.assertContains(self.client.get(reverse("resource_requests:mine")), 'dir="ltr"')

    def test_public_calculator_in_arabic(self):
        self.client.logout()
        r = self.client.get(reverse("sustainability:calculator"), HTTP_ACCEPT_LANGUAGE="ar")
        self.assertContains(r, "حاسبة التوفير")
        self.assertContains(r, "58,800 درهم")  # UAE number format: comma thousands

    def test_notifications_are_stored_in_both_languages(self):
        req_services.submit_request(self.w.requester, {
            "department": self.w.me, "selected_asset": self.w.asset, "quantity": 1, "purpose": "Lab",
            "destination_campus": "Main"}, uuid.uuid4().hex)
        n = Notification.objects.filter(recipient=self.w.approver, channel=Channel.IN_APP).get()
        self.assertIn("asks for", n.message)
        self.assertIn("يطلب", n.message_ar)
        with translation.override("ar"):
            self.assertEqual(n.text, n.message_ar)
        with translation.override("en"):
            self.assertEqual(n.text, n.message)

    def test_msg_renders_callables_in_each_language(self):
        from django.utils.translation import gettext_lazy
        m = Msg(gettext_lazy("Cancelled: %(n)s × %(name)s. Reason: %(reason)s"), n=2, name="Desk", reason=lambda: gettext_lazy("no notes"))
        self.assertEqual(m.render("en"), "Cancelled: 2 × Desk. Reason: no notes")
        self.assertIn("بلا ملاحظات", m.render("ar"))

    def test_service_errors_are_translated_when_shown(self):
        with translation.override("ar"):
            self.assertEqual(tr(ValidationFailed("Give a reason")), "اذكر سببًا")
            self.assertEqual(aed(1260), "1,260 درهم")
        with translation.override("en"):
            self.assertEqual(aed(1260), "AED 1,260")

    @override_settings(LANGUAGE_CODE="ar")
    def test_every_catalogue_entry_is_translated(self):
        import polib
        from django.conf import settings
        po = polib.pofile(str(settings.BASE_DIR / "locale" / "ar" / "LC_MESSAGES" / "django.po"))
        missing = [e.msgid for e in po if not e.obsolete and (not e.translated() or "fuzzy" in e.flags)
                   and "{" not in e.msgid and "append-only" not in e.msgid and not e.msgid.startswith(("Fix these", "Some units"))]
        self.assertEqual(missing, [])
