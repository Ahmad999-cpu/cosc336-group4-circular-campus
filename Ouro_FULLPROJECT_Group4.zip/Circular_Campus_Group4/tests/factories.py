"""Small helpers that build a consistent world for tests (no extra library needed)."""
import itertools
from decimal import Decimal

from apps.access.models import PERMISSIONS, Department, Permission, Role, RoleAssignment, User
from apps.catalogue.models import Asset, Category
from apps.common.enums import Condition
from apps.resource_requests.models import ResourceRequest

_seq = itertools.count()


def role(name, *codes, limit=None):
    for c in codes:
        Permission.objects.get_or_create(code=c, defaults={"description": PERMISSIONS.get(c, c)})
    r, _ = Role.objects.get_or_create(name=name, defaults={"approval_limit": limit})
    r.permissions.set(codes)
    return r


def user(name, dept, *roles_with_scope):
    u = User.objects.create_user(f"{name.lower().replace(' ', '.')}{next(_seq)}@t.local", "pw-123456!", full_name=name, department=dept)
    for r, scope in roles_with_scope:
        RoleAssignment.objects.create(user=u, role=r, scope_department=scope)
    return u


class World:
    """University -> Engineering -> {CS, ME}. CS owns a published lot of monitors."""

    def __init__(self, qty=1, value="650"):
        self.uni = Department.objects.create(name="Uni", unit_type="University")
        self.eng = Department.objects.create(name="Engineering", parent=self.uni)
        self.cs = Department.objects.create(name="CS", parent=self.eng)
        self.me = Department.objects.create(name="ME", parent=self.eng)
        self.r_req = role("Requester", "request.submit", "transfer.receive")
        self.r_cus = role("Custodian", "asset.register", "asset.publish", "asset.custody")
        self.r_app = role("Approver", "request.approve", limit=Decimal("2000"))
        self.r_fac = role("Facilities", "transfer.dispatch")
        self.custodian = user("Cara", self.cs, (self.r_cus, self.cs))
        self.approver = user("Adam", self.eng, (self.r_app, self.eng))
        self.requester = user("Rana", self.me, (self.r_req, self.me))
        self.requester2 = user("Omar", self.me, (self.r_req, self.me))
        self.facilities = user("Faisal", self.uni, (self.r_fac, None))
        self.category = Category.objects.create(name="Monitors")
        self.asset = Asset.objects.create(
            name="Dell monitor", category=self.category, owner_department=self.cs, custodian=self.custodian,
            quantity=qty, available_quantity=qty, condition=Condition.GOOD, estimated_value=Decimal(value),
            location_campus="Main", location_building="B1", location_room="1.12")
        self.asset.mark_available(self.custodian)
        self.asset.publish(self.custodian)

    def request(self, who=None, qty=1):
        return ResourceRequest.objects.create(
            requester=who or self.requester, department=self.me, category=self.category, purpose="Lab",
            quantity=qty, destination_campus="Main", destination_building="B2", selected_asset=self.asset,
            idempotency_key=f"k{next(_seq)}")
