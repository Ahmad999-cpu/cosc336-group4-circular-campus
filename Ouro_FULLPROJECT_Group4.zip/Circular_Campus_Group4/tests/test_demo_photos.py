import shutil
import tempfile
from pathlib import Path
from unittest import mock

from django.core.management import call_command
from django.test import TestCase, override_settings
from PIL import Image

from apps.catalogue.models import Asset
from apps.web.management.commands import demo_photos

MEDIA = tempfile.mkdtemp()


@override_settings(MEDIA_ROOT=MEDIA)
class DemoPhotosTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("seed_demo", verbosity=0)

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        Image.new("RGB", (40, 20), (10, 20, 30)).save(self.dir / "stackable-lab-stool.jpg")
        patcher = mock.patch.object(demo_photos, "PHOTO_DIR", self.dir)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.addCleanup(shutil.rmtree, self.dir, True)

    def test_attaches_once_and_card_shows_it(self):
        self.assertEqual(demo_photos.attach_demo_photos(), 1)
        self.assertEqual(demo_photos.attach_demo_photos(), 0)
        stool = Asset.objects.get(name="Stackable lab stool")
        self.assertIn("demo-photo-stackable-lab-stool", stool.photo.file.name)
        self.assertIsNone(Asset.objects.get(name="Mobile whiteboard").photo)

    def test_replace_keeps_a_single_photo(self):
        demo_photos.attach_demo_photos()
        self.assertEqual(demo_photos.attach_demo_photos(replace=True), 1)
        stool = Asset.objects.get(name="Stackable lab stool")
        self.assertEqual(stool.attachments.count(), 1)
