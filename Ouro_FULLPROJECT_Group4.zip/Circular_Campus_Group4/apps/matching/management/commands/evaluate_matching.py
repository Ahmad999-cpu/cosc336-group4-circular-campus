"""Phase 7 AI evaluation for matching (AI feature 2): relevance on labelled English and Arabic queries.

    python manage.py seed_demo
    python manage.py evaluate_matching            # prints a Markdown table
    python manage.py evaluate_matching --out docs/evaluation/matching.md

Runs the real Find pipeline (hard rules, embeddings, eight factors) inside a transaction that is rolled back,
so nothing is saved. A query counts as a hit when a result is in one of its expected categories.
"""
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from apps.access.models import User
from apps.matching import services
from apps.matching.embeddings import get_embedder

LABELLED = [  # (query, expected categories, language)
    ("display screen for a lab PC", {"Monitors"}, "en"),
    ("two monitors for a workstation", {"Monitors"}, "en"),
    ("seats for a seminar", {"Chairs", "Stools"}, "en"),
    ("office chair with armrests", {"Chairs"}, "en"),
    ("something to show slides in a lecture", {"Projectors"}, "en"),
    ("beamer for a classroom", {"Projectors"}, "en"),
    ("USB-C dock for laptops", {"Docking stations"}, "en"),
    ("storage for books", {"Shelving"}, "en"),
    ("bookcase", {"Shelving"}, "en"),
    ("scope to look at signals", {"Oscilloscopes"}, "en"),
    ("bench power supply for an electronics lab", {"Power supplies"}, "en"),
    ("3D printer for prototyping", {"3D printers"}, "en"),
    ("board to write on for a meeting room", {"Whiteboards"}, "en"),
    ("شاشة عرض", {"Monitors"}, "ar"),
    ("شاشتان لمختبر", {"Monitors"}, "ar"),
    ("كراسي لقاعة الندوات", {"Chairs", "Stools"}, "ar"),
    ("كرسي مكتب", {"Chairs"}, "ar"),
    ("بروجكتر للمحاضرات", {"Projectors"}, "ar"),
    ("عارض شرائح", {"Projectors"}, "ar"),
    ("رفوف للكتب", {"Shelving"}, "ar"),
    ("طابعة ثلاثية الأبعاد", {"3D printers"}, "ar"),
    ("مزود طاقة للمختبر", {"Power supplies"}, "ar"),
    ("سبورة متحركة", {"Whiteboards"}, "ar"),
    ("راسم الإشارة", {"Oscilloscopes"}, "ar"),
    ("منصة توصيل للابتوب", {"Docking stations"}, "ar"),
]


class _Rollback(Exception):
    pass


class Command(BaseCommand):
    help = "Measure matching relevance on labelled English and Arabic queries (nothing is saved)."

    def add_arguments(self, parser):
        parser.add_argument("--user", default="club@demo.local", help="Requester whose unit is excluded (default: the club)")
        parser.add_argument("--out", help="Also write the Markdown report to this file")

    def handle(self, *args, user, out=None, **opts):
        u = User.objects.filter(email=user).first()
        if u is None:
            raise CommandError(f"No user {user}. Run seed_demo first.")
        rows = []
        try:
            with transaction.atomic():
                for q, expected, lang in LABELLED:
                    o = services.find(q, u)
                    ranked = [r.asset.category.name for r in o.suitable + o.weak]
                    rank = next((i + 1 for i, c in enumerate(ranked) if c in expected), None)
                    top = o.suitable[0] if o.suitable else (o.weak[0] if o.weak else None)
                    rows.append({"q": q, "lang": lang, "expected": ", ".join(sorted(expected)), "rank": rank,
                                 "top": f"{top.asset.name} ({float(top.compatibility_score):.0f})" if top else "–",
                                 "n": len(ranked)})
                raise _Rollback
        except _Rollback:
            pass

        def metrics(sub):
            n = len(sub) or 1
            return {"n": len(sub), "hit1": sum(1 for r in sub if r["rank"] == 1) / n,
                    "hit3": sum(1 for r in sub if r["rank"] and r["rank"] <= 3) / n,
                    "mrr": sum(1 / r["rank"] for r in sub if r["rank"]) / n,
                    "empty": sum(1 for r in sub if r["n"] == 0) / n}

        e = get_embedder()
        lines = [f"# Matching relevance ({e.name} embedder, {e.model_name})", "",
                 "| Queries | Hit@1 | Hit@3 | MRR | No result |", "|---|---|---|---|---|"]
        for label, sub in [("All", rows), ("English", [r for r in rows if r["lang"] == "en"]), ("Arabic", [r for r in rows if r["lang"] == "ar"])]:
            m = metrics(sub)
            lines.append(f"| {label} ({m['n']}) | {m['hit1']:.0%} | {m['hit3']:.0%} | {m['mrr']:.2f} | {m['empty']:.0%} |")
        lines += ["", "| Query | Expected | First relevant at | Top result (score) |", "|---|---|---|---|"]
        for r in rows:
            lines.append(f"| {r['q']} | {r['expected']} | {r['rank'] or 'not found'} | {r['top']} |")
        report = "\n".join(lines) + "\n"
        self.stdout.write(report)
        if out:
            with open(out, "w", encoding="utf-8") as fh:
                fh.write(report)
