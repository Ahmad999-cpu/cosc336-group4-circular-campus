from django.apps import AppConfig


class MatchingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.matching"
    label = "matching"
    verbose_name = "Matching Orchestration"

    def ready(self):
        from . import receivers  # noqa: F401
