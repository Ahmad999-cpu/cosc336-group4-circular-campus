"""Attach demo photos to the demo assets. Safe to run more than once.

    python manage.py demo_photos            # attach photos to assets that have none yet
    python manage.py demo_photos --replace  # swap in new files for photos this command added earlier

Put one image per asset in demo/asset_photos/, named after the asset with spaces as dashes, e.g.
    demo/asset_photos/stackable-lab-stool.jpg
    demo/asset_photos/dell-24-inch-monitor.png
The photos are AI-generated illustrations for the demo, not pictures of KU's real items.
"""
import mimetypes
from pathlib import Path

from django.conf import settings
from django.core.files import File
from django.core.management.base import BaseCommand
from django.utils.text import slugify

from apps.catalogue.models import Asset, AssetAttachment

PHOTO_DIR = Path(settings.BASE_DIR) / "demo" / "asset_photos"
EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp")
MARK = "demo-photo-"  # file name prefix, so --replace only touches photos this command added


def find_photo(asset_name: str):
    stem = slugify(asset_name)
    for ext in EXTENSIONS:
        path = PHOTO_DIR / f"{stem}{ext}"
        if path.exists():
            return path
    return None


def attach_demo_photos(replace: bool = False, stdout=None) -> int:
    added = 0
    for asset in Asset.objects.all():
        path = find_photo(asset.name)
        if not path:
            continue
        images = [a for a in asset.attachments.all() if a.file_type.startswith("image/")]
        ours = [a for a in images if MARK in a.file.name]
        if images and not (replace and ours):
            continue  # keep real photos, and our own unless asked to replace them
        for old in ours:
            old.file.delete(save=False)
            old.delete()
        next_no = (max([a.attachment_no for a in asset.attachments.all()], default=0)) + 1
        with path.open("rb") as fh:
            att = AssetAttachment(asset=asset, attachment_no=next_no, uploaded_by=asset.custodian,
                                  file_type=mimetypes.guess_type(path.name)[0] or "image/jpeg")
            att.file.save(f"{MARK}{path.name}", File(fh), save=True)
        added += 1
        if stdout:
            stdout.write(f"  photo added: {asset.name}")
    return added


class Command(BaseCommand):
    help = "Attach AI-generated demo photos from demo/asset_photos/ to the matching demo assets."

    def add_arguments(self, parser):
        parser.add_argument("--replace", action="store_true", help="Replace photos this command added before.")

    def handle(self, *args, **opts):
        if not PHOTO_DIR.exists():
            self.stdout.write(f"No folder at {PHOTO_DIR}. Add photos there first.")
            return
        n = attach_demo_photos(replace=opts["replace"], stdout=self.stdout)
        self.stdout.write(self.style.SUCCESS(f"{n} demo photo(s) attached."))
